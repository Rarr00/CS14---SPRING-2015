/*
    Name: Adrian Dy
    SID: 861118847
    Date: 4/16/2015

*/

#include <iostream>
#include "lab2.h"

//#include <forward_list>


int global;

int primeCount(forward_list<int> lst)
{
    int countPrimes = 0;
    bool var;
    for(auto iElement = lst.cbegin(); iElement != lst.cend(); iElement++)
    {
        global =  *iElement/2;
        var = isPrime(*iElement);
        if(var == true)
            countPrimes++;
    }
    return countPrimes;
}

bool isPrime(int i)
{
    if(global == 1)
        return true;
    else
    {
        if(i % global ==0)
            return false;
        else
            global = global-1;
            return isPrime(i);
    }
    /*
    for(int j = 2; j < i; j++)
    {
        if(i % j == 0)
            return false;
    }
    return true;*/
}



/*
template<typename T>
List<T>::List()
{
    head = NULL;
    tail = NULL;
}

template<typename T>
List<T>::~List()
{
    Node<T>* pDelete = head;

    while(pDelete != NULL)
    {
        head = head->next;
        delete pDelete;
        pDelete = head;
    }
    head = tail = NULL;
}

template<typename T>
void List<T>::pushBack(const T& value)
{
    if(!head)
    {
        head = new Node<T>(value);
        tail = head;
        return;
    }
    tail->next = new Node<T>(value);
    tail = tail->next;
}

template<typename T>
void List<T>::elementSwap(int pos)
{
    Node<T>* current = head;
    int cnt = 0;

    if(current == NULL)
        cout << "List is empty" << endl;
    else
    {
        while(current != NULL)              // counts size of list
        {
            current = current->next;
            cnt++;
        }
    }

    int pos2 = pos + 1;
    if( (pos>cnt || pos<0) || (pos2>cnt || pos2<0) )
    {
        cout << "values are out of bounds" << endl;
        return;
    }

    if(head == NULL)
        cout << "List is empty" << endl;
     else
        {
            Node<T>* forPos = head;
            int cnt1 = 1;

            while(cnt1 < pos)     //fori will point to ith node
            {
                forPos = forPos->next;
                cnt1++;
            }


            Node<T>* forPos2 = head;
            int cnt2 = 1;

            while(cnt2 < pos2)     //fori will point to jth node
            {
                forPos2 = forPos2->next;
                cnt2++;
            }
            Node<T>*  temp = forPos2->next;
            forPos2->next = forPos->next;
            forPos->next = temp;
        }
}*/



