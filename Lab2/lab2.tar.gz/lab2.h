/*
    Name: Adrian Dy
    SID: 861118847
    Date: 4/16/2015

*/

#ifndef LAB2_H_INCLUDED
#define LAB2_H_INCLUDED

#include <forward_list>
using namespace std;

int primeCount(forward_list<int> lst);
bool isPrime(int i);

template<typename T>
void Display(const T& input)
{
    for(auto iElement = input.cbegin(); iElement != input.cend(); iElement++)
        cout << *iElement << " ";

    cout << endl;
}

template<typename T>
forward_list<T> listCopy(forward_list<T> L, forward_list<T>& P)
{
    L.reverse();
    P = L;
    return P;
}

template<typename T>        //does not work!
void printLots(forward_list<T> L, forward_list<int>& P)
{
    for(auto forP = P.cbegin(); forP != P.cend(); forP++)
        for(auto forL = L.cbegin(); forL != L.cend(); forL++)
            {
                if(*forL == *forP)
                    cout << *forL << " ";
            }
    cout << endl;
}

template<typename T> class Node;
template<typename T> class List;

template<typename T>
class Node
{
    friend class List<T>;
public:
        Node(const T &val)
        {
            value = val;
            next = NULL;
        }                        //             : value(value), next(NULL){}
        T value;
        Node* next;
};

template<typename T>
class List
{

public:
    List();
    ~List();
    void pushBack(const T& value);
    void elementSwap(int pos);      //made void not List<T> elementSwap(int pos)
    void print() const;

private:
    Node<T> *head;
    Node<T> *tail;

};

template<typename T>
List<T>::List()
{
    head = NULL;
    tail = NULL;
}

template<typename T>
List<T>::~List()
{
    Node<T>* pDelete = head;

    while(pDelete != NULL)
    {
        head = head->next;
        delete pDelete;
        pDelete = head;
    }
    head = tail = NULL;
}

template<typename T>
void List<T>::pushBack(const T& value)
{
    if(!head)
    {
        head = new Node<T>(value);
        tail = head;
        return;
    }
    tail->next = new Node<T>(value);
    tail = tail->next;
}

template<typename T>
void List<T>::print() const
{
   Node<T>* point = head;

   if(head == NULL)
    cout << "List is empty " << endl;
   else
   {
       while(point != NULL)
       {
           cout << point->value << " "; // display value
           point = point->next;
       }
   }
   cout << endl;
}

template<typename T>
void List<T>::elementSwap(int pos)
{
    Node<T>* current = head;
    int cnt = 0;

    if(current == NULL)
        cout << "List is empty" << endl;
    else
    {
        while(current != NULL)              // counts size of list
        {
            current = current->next;
            cnt++;
        }
    }

    int pos2 = pos + 1;
    if( (pos>cnt || pos<0) || (pos2>cnt || pos2<0) )
    {
        cout << "values are out of bounds" << endl;
        return;
    }

    if(head == NULL)
        cout << "List is empty" << endl;
     else
        {
            Node<T>* forPos = head;
            int cnt1 = 1;

            while(cnt1 < pos)     //fori will point to ith node
            {
                forPos = forPos->next;
                cnt1++;
            }


            Node<T>* forPos2 = head;
            int cnt2 = 1;

            while(cnt2 < pos2)     //fori will point to jth node
            {
                forPos2 = forPos2->next;
                cnt2++;
            }

            Node<T>*  temp = forPos2->next;
            forPos2->next = forPos->next;       //does not swap!!!
            forPos->next = temp;

        }
}

#endif // LAB2_H_INCLUDED