/*
    Name: Adrian Dy
    SID: 861118847
    Date: 4/16/2015

*/

#include <iostream>
#include <forward_list>
#include "lab2.h"
//using namespace std;

//printLots does not work as intended

int main()
{
    forward_list<int> one;

    one.push_front(2);
    one.push_front(3);
    one.push_front(5);
    one.push_front(7);
    one.push_front(10);
    one.push_front(30);
    cout << "forward_list one: ";
    Display(one);           //display list one

    cout << endl;
    forward_list<int> two;
    two = listCopy(one,two);        //reverses list one and stores to list two
    cout << "forward_list two after listCopy(one,two): " << endl;
    Display(two);
    cout << endl;
    int cnt = 0;
    cnt = primeCount(one);
    cout << "the number of primes in forward_list one using primeCount(one): " << cnt << endl;
    cout << endl;

    forward_list<int> three;
    three.push_front(10);
    three.push_front(5);
    three.push_front(3);
    three.push_front(1);
    Display(three);
    cout << endl;
    forward_list<char> four;
    four.push_front('K');
    four.push_front('J');
    four.push_front('I');
    four.push_front('H');
    four.push_front('G');
    four.push_front('F');
    four.push_front('E');
    four.push_front('D');
    four.push_front('C');
    four.push_front('B');
    four.push_front('A');
    Display(four);
    cout << endl;
    cout << "printLots(four, three): prints values inside four corresponding to int values in three " << endl;
    printLots(four, three);     //prints values inside four corresponding to int values in three
    cout << endl;

    List<int> first;
    first.pushBack(10);
    first.pushBack(5);
    first.pushBack(11);
    first.pushBack(66);
    first.pushBack(3);
    cout << "List one: ";
    first.print();

    cout << "After swap: ";
    first.elementSwap(1);           // does not swap!!!fubar
    first.print();





    return 0;
}
/*
int primeCount(forward_list<int> lst)
{
    int countPrimes = 0;
    bool var;
    for(auto iElement = lst.cbegin(); iElement != lst.cend(); iElement++)
    {
        var = isPrime(*iElement);
        if(var == true)
            countPrimes++;
    }
    return countPrimes;
}

bool isPrime(int i)
{
    for(int j = 2; j < i; j++)
    {
        if(i % j == 0)
            return false;
    }
    return true;
} */